from fastapi import FastAPI
from .database import Base, engine
from .routers import employees, tasks

# Create tables automatically
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Employee Task API")

app.include_router(employees.router)
app.include_router(tasks.router)

@app.get("/")
def root():
    return {"message": "Employee Task API working!"}
